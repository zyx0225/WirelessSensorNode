void timer_start(unsigned char t_id, unsigned char t_secs, unsigned char t_isPeriodic);
