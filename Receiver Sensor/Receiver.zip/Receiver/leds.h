void leds_init(void);
void leds_on(unsigned char led);
void leds_off(unsigned char led);
